import React from "react";
import styled from "styled-components";
import './navbar.css'
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
const NavLinksContainer = styled.div`
  height: 100%;
  display: flex;
  align-items: center;
  background-color: black;
 
  padding-bottom: 10px;

`;

const LinksWrapper = styled.ul`
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: row;
  height: 100%;
  list-style: none;

`;

const LinkItem = styled.li`
  


li:before {
  content: "";
  position: absolute;
  width: 100%;
  height: 2px;
  bottom: 0;
  left: 0;
  background-color: #FFF;
  visibility: hidden;
  transform: scaleX(0);
  transition: all 0.3s ease-in-out;
}
li:hover::before {
  visibility: visible;
  transform: scaleX(1);
  cursor: pointer;
}
 
`;

const Link = styled.p`
  text-decoration: none;
  color: inherit;
  font-size: inherit;
  color: white;
  display: inline-block;
  position: relative;
  

`;

export function NavLinks(props) {
  return (
    <NavLinksContainer>
      <LinksWrapper>
      <div class="middle">
          <li>Home</li>
      
        
          <li>About Us</li>
      
        
         <div className="lidropdown"> 
         <li className="lidropbtn">Services </li>
         {/* <KeyboardArrowDownIcon className="drop_down_arrow"/> */}
         <div class="lidropdown-content">
           <div className="lidrop_spacer">
      <div className="lidrop_h4"><h4>Data Science</h4>
     <p> Latest technology that reshape your business
thoroughly with advance features.</p>

<p>Artificial Intelligence</p>
<p>Business Intelligence</p>
<p>Deep Learning</p>
<p>Machine Learning</p>
<p>Chatbots</p>
<p>AIOps</p>
<h4>Data Analytics</h4>
<p>New factors of data and analysis that give
a different outlook to the business.





</p>

<p>Predictive Analytics</p>
<p>Text Analytics</p>
<p>IoT Analytics</p>
<p>Customer 360</p>
<p>Video Analytics</p>

      </div>
     <div className="li_drop_two"> <h4>Big Data Implementation</h4>
     <p>A small or large data that transform your
business & provide new strategies.</p>

<p>Data Migration</p>
<p>Data Warehouse</p>
<p>Data Virtualization</p>
<p>Data Lake</p>
<p>Big Data</p>





ITSM
<h4>Data Visualization</h4>
     <p>Qlik Sense & QlikView</p>

<p>Microsoft Power BI</p>
<p>DevOps</p>
<h4>Elastic Solution</h4>
<h4>Security</h4>
<h4>CloudOps</h4>
</div>
     <div> <h4>To Explore More Opprtunity</h4>
     
     </div>
      
      </div>
    </div>
         
         </div>
        
        
  <div className="lidropdown"> 
         <li className="lidropbtn">Industries </li>
         {/* <KeyboardArrowDownIcon/> */}
         <div class="lidropdown-content">
           <div className="lidrop_spacer">
           <div className="lidrop_h4">
     <p>Banking and Financial</p>
     



<p>Insurance</p>
<p>Manufacturing</p>
<p>Transportation and Logistics</p>
<p>Healthcare</p>



      </div>
     <div className="li_drop_two"> 
     




     <p>Retail</p>

<p>Media and Entertainment</p>
<p>Education</p>
<p>Automotive</p>
<p>Travel and Hospitality</p>
</div>
     <div> <p> Oil and Gas</p>
    <p>Real Estate and E-commerce</p>
    <p>Telecom</p>
    <p>Food and Beverages</p>
    <p>Energy</p>




     </div>
      </div>
    </div>
         
         </div>
      
        
          <li>Case Study</li>
      
        
          <li>Blog</li>
      
        
          <li>Contact</li>
          </div>
      
      </LinksWrapper>
    </NavLinksContainer>
  );
}
